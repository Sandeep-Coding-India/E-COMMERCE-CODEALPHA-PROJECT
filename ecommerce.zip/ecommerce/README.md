# E-Commerce Website  
  
Complete working e-commerce website with authentication, cart, and orders.  
  
## Quick Start  
  
1. Make sure MongoDB is installed and running  
2. Run: npm start  
3. Open: http://localhost:5000/index.html  
  
## Features  
- User Registration and Login with JWT  
- Product Listing and Details  
- Shopping Cart with LocalStorage  
- Order Processing  
- Password Hashing with Bcrypt 
